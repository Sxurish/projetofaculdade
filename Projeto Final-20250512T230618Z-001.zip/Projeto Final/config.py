
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Sxurishsxh1#',
    'database': 'projetofaculdade'
}
